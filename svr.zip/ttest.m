 clear
[heart_scale_label, heart_scale_inst] = libsvmread('triazines_scale');
% length(heart_scale_label)
%  length(nonzeros( heart_scale_inst))
count=round(0.6*length(heart_scale_label));
heart=heart_scale_inst(1:count,:);
 b=heart_scale_label(1:count,:);
 r=ones(count,1);
 A=[heart,r]';
%   t2=clock;
%  model2 = train(b, A', '-c 0.892857142857 -s 12  -e  0.000001 -p 0.01 ');
%  a1=etime(clock,t2)
%   t0 = clock;
%  model1 = train(b, A', '-c 0.892857142857 -s 11  -e  0.000001 -p 0.01 '); 
%   a2=etime(clock,t0)
e= 1e-2;
    C=1/length(b)*(10^(1));
 [x,info]=SemismoothNewton_SVR(A,b,e,C);
info
%  counter=round(0.4*length(heart_scale_label));
% E=heart_scale_inst(end-counter+1:1:end,:);
% A=[E,ones(counter,1)]';
% Y=heart_scale_label(end-counter+1:1:end,:);
% n=length(Y);
% y=Y'-x'*A;
% MSE=1/n*y*y';
% vpa(MSE)
% MAE=1/n*sum(abs(y))
%   [predict_label, accuracy, prob_estimates] = predict(Y, E, model1);
% [predict_label, accuracy, prob_estimates] = predict(Y, E, model2);
