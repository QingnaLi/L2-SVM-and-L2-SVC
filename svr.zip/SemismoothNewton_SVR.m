 function [x,info] = SemismoothNewton_SVR(A,b,e,C)
%% Train epsilon-L2-loss L2-regularized linear SVR by Semismooth Newton method
% This code is to use semismooth Newton's method 
% to solve epsilon-L2-regularized support vector regression problem.
% min_x 0.5*x'*x+C*sum(max(|x' A(:,i)− bi|-epsilon,0)^2))


% it is based on the following paper 
% Yin J. and Li Q.N.*, A Semismooth Newton Method for Support Vector Classification 
% and Regression, Computational Optimization and Applications., 2019, 73(2) ， 477-508
% last modified by Juan Yin and Qingna Li 2022/07/09 
% If you have comments, please contact qnl@bit.edu.cn
% 
% Input:
% A: d-by-n training data matrix 
%    (n is number of data points and d is dimension of one data point)
% b: n-by-1 target value
% e: epsilon>0.
%    The parameter is given so that the loss is zero if |x' A(:,i)− bi|≤epsilon
% C: cost parameter of the support vector regression
%
% Output:
% x: d-by-1 weight vector 
% info;
%    info.time: time used for the total SemismoothNewton program
%    info.k:  the number of iterations of the SemismoothNewton program
%    info.res:  the gradient residuals
%    info.f:  the function value
%    info.totalcgiter: the number of iterations of CG
   
  format short;
%   format long;
%  xvector = [];
% yvector = [];
t0 = clock;
[m,n] = size(A);
x = ones(m,1);
maxk = 100; 
rho = 0.5;  
sigma = 1.0e-4;
eta0 = 0.5;
eta1 = 0.5;
maxit = 200;
tol = 1e-2;
k = 0;
epsilon = 1.0e-6;
cg_time = 0;
B = A;
% idx = find(A'*x-b<0);
% B(:,idx) = -A(:,idx);
Axb = A'*x-b;
 idx = find(Axb<0);
 B(:,idx) = -A(:,idx);
[ f0,c1,idx1,c] = func(Axb,x,e,C,b);
g = gradien(B,x,C,c1,c);
  normg = norm(g);
  totalcgiter = 0;
while(k<maxk&normg >epsilon)
    muk = min(eta0,eta1*normg);
    % tol = muk;
   rhs = -g;
   cg_time0 = clock;
   Asub = A(:,idx1);
   [d,flag,relres,iterk] = cg(Asub,m,C,tol,maxit,rhs,muk,e,normg);
   totalcgiter = totalcgiter+iterk;
   cg_time = cg_time + etime(clock,cg_time0);
   mk = 0;
   alpha = rho^mk;
%    descent = g'*d;
  descent = sum(g.*d);
   y = x + alpha*d;
   
   Axb = A'*y-b;
    [f,c1,idx1,c] = func(Axb,y,e,C,b);
    while (mk<10&f>f0+sigma*alpha*descent+1.0e-4)
        mk = mk+1;
        alpha = rho^mk;
        y = x+ alpha*d;
        Axb = A'*x-b;
   [ f,c1,idx1,c] = func(Axb,y,e,C,b);
    end
    %x = x+alpha*d;
    x = y;   
%     B = A;
%  idx = find(A'*x-b<0);
%  B(:,idx) = -A(:,idx);
  B = A;
 idx = find(Axb<0);
 B(:,idx) = -A(:,idx);
 
  g = gradien(B,x,C,c1,c);
  f0 = f;
  normg = norm(g);
%      yvector = [yvector log(normg)];
  fprintf('k = %d, alpha = %f, cg iteration number = %d  norm(g) = %f\n ',k,alpha, iterk,normg)
   k = k+1;
%    xvector = [xvector k]; 
% etime(clock,t0);
%    xvector = [xvector etime(clock,t0)]; 
end
% xvector
% yvector
 time_used = etime(clock,t0);
fprintf('Newton-CG: computing time for linear systems solving (cgs time) ====%d \n', cg_time)
fprintf('Newton-CG: computing time used for the total program =====%d \n',time_used)
info.time = time_used;
info.k = k;
info.res = normg;
info.f = f;
info.totalcgiter = totalcgiter;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% subfunctions
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [d,flag,relres,iterk] = cg(Asub,m,C,tol,maxit,rhs,muk,e,normg)
% Initializations
r = rhs;  %We take the initial guess x0 = 0 to save time in calculating A(x0) 
n2b = normg;    % norm of D
tolb = tol * n2b;  % relative tolerance 
d = zeros(m,1);
flag = 1;
iterk = 0;
relres = 1000; %%% To give a big value on relres
% Precondition 
z = r;  
% z = r./2;  
rz1 = r'*z; 
% rz2 = D; 
rz2 = 1; 
p = z;
% CG iteration
for k = 1:maxit
   if k > 1
       beta = rz1/rz2;
       p = z + beta*p;
   end
   %w = Jacobian_matrix(A,x,b,m,n,lambda,p); %w = A(d); 
   w = Jacobia(Asub,C,e,p); % W = A(d)
   denom = p'*w;
   iterk = k;
   relres = norm(r)/n2b;              %relative residue = norm(r) / norm(b)
   if denom <= 0 
       sssss = 0
       d = p/norm(p); % p is not a descent direction
       break % exit
   else
       alpha = rz1/denom;
       d = d + alpha*p;
       r = r - alpha*w;
   end
   z = r; 
% z = r./3;  
   if norm(r) <= tolb % Exit if Hp=b solved within the relative tolerance
       iterk = k;
       relres = norm(r)/n2b;      %relative residue = norm(r) / norm(b)
       flag = 0;
       break
   end
   rz2 = rz1;
   rz1 = r'*z;
end
%% objective function
function [f,c1,idx1,c] = func(Axb,x,e,C,b)
tmp = abs(Axb)-e;
c = max(0,tmp);
idx1 = find(c);
c1 = c(idx1);
% f = 0.5*sum(x.*x)+C*sum(c.*c);
f = 0.5*sum(x.*x);
f = f+C*sum(c1.*c1);
% f = 0.5*sum(x.*x)+C*sum(c.*c);
return
%% gradient function
function g = gradien(B,x,C,c1,c)
% B = A;
% idx = find(A'*x-b<0);
% B(:,idx) = -A(:,idx);
   tmp = B*c;
% tmp = B(:,idx1)*c1;
% max(tmp1-tmp), min(tmp1-tmp)
% pause
g = 2*C*tmp;
g = x+g;
return
%% generalized jacobian function
%function  vs = Jacobian(A,B,x,n,lambda,p)
function  vp = Jacobia(Asub,C,e,p)
%    idx  = find(c);
%    tmp3 = A(:,idx);
%Asub = A(:,idx1);
  tmp = Asub'*p;
  tmp1 = Asub*tmp;
    vp = (1+1.0e-10)*p+ 2*C*tmp1;