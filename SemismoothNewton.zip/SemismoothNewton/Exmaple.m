function Exmaple
%% 
%This is an example that illustrates how to use SemismoothNewtonTrain.m and
%SemismoothNewtonPredict.m to solve binary classification problem 
%with L2-loss L2-regularized linear SVM by Semismooth Newton method.
% it is based on the following paper
% Yin J. and Li Q.N.*, A Semismooth Newton Method for Support Vector Classification 
%and Regression, Computational Optimization and Applications., 2019, 73(2) ， 477-508

%{
%First we generate training and testing datasets, then we use the function SemismoothNewtonTrain 
%to train L2-loss L2-regularized linear SVM by Semismooth Newton method,
%finally we use the function SemismoothNewtonPredict to predict on testing data.
%}
% last modified by Cheng Jiang and Qingna Li 2020/08/09 
% If you have comments, please contact qnl@bit.edu.cn


%% Generate training and testing datasets
fprintf('---------------Generating testing data......------------\n')
t0 = tic;
dim =30;
size = [1, dim];
num = 1e6;

mu1 = zeros(size);
sigma1 = 2*ones(size);
noise = mvnrnd(zeros(size), ones(size), num);
x1 = mvnrnd(mu1, sigma1, num) + noise;
y1 = -1*ones(num, 1); % first class labelled by -1

mu2 = 2*ones(size);
sigma2 = 3*ones(size);
noise = mvnrnd(zeros(size), ones(size), num);
x2 = mvnrnd(mu2, sigma2, num) + noise;
y2 = ones(num, 1); % second class labelled by 1

data = [x1; x2];
label = [y1; y2];

total_num = 2*num; % number of all samples
dex = randperm(total_num);
num_training = 0.7*total_num;

training_data = data(dex(1:num_training),:);
training_label = label(dex(1:num_training),:);
testing_data = data(dex(num_training+1:total_num),:);
testing_label = label(dex(num_training+1:total_num),:);
t00=toc(t0);
fprintf('---------Training data and test data are generated. Time used %f--------\n', t00)
%% Train L2-loss L2-regularized linear SVM by Semismooth Newton method

A = training_data';
b = training_label';
C = 1; % cost parameter
fprintf('-------------Semismooth Newton method starts--------- \n\n')
t0 = tic;
model = SemismoothNewtonTrain(A, b, C);
fprintf('-------------Semismooth Newton method finished--------- \n\n')

%% Predict on data by the trained L2-loss L2-regularized linear SVM model

predicting_label = SemismoothNewtonPredict(model, testing_data');
error_rate = mean(predicting_label ~= testing_label)*100;
fprintf('Newton-CG: Error rate of predicting on testing dataset ===== %.2f%%\n', error_rate);
